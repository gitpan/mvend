# Vend/UserSearch -- a placeholder for a user-generated Search
# routine

package Vend::UserSearch;

1;
